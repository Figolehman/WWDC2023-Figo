//
//  PopupView.swift
//  RumahIblis
//
//  Created by Figo Alessandro Lehman on 05/04/23.
//

import SwiftUI

struct PopupView: View {
    @State var result: String
    @Binding var info: String
    @Binding var index: Int
    @Binding var correctAnswer: String
    var body: some View {
        VStack(alignment: .center){
            Text(result)
            if result == "Wrong"{
                Text("The right answer is \(correctAnswer)")
            }
            Text(info).padding()
        }
        .frame(width: 300, height: 300)
            .background(Color.white)
            .cornerRadius(20)
    }
}

struct PopupView_Previews: PreviewProvider {
    static var previews: some View {
        PopupView(result: "Correct", info: .constant("This ghost is prettysadasdasdasdasdasdas dasd asdasd as d"), index: .constant(1), correctAnswer: .constant("Pocong"))
    }
}
