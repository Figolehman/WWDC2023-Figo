//
//  ProgressBar.swift
//  RumahIblis
//
//  Created by Figo Alessandro Lehman on 05/04/23.
//

import SwiftUI

struct ProgressBar: View {
    @Binding var index: Int
    var body: some View {
        ZStack(alignment: .leading){
            Rectangle()
                .frame(maxWidth: 350, maxHeight: 5).foregroundColor(.gray)
                .cornerRadius(20)
            
            Rectangle()
                .frame(width: CGFloat(35 * (index + 1)), height: 5)
                .cornerRadius(20)
        }
    }
}

struct ProgressBar_Previews: PreviewProvider {
    static var previews: some View {
        ProgressBar(index: .constant(0))
    }
}
