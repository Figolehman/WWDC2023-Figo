//
//  IblisViewModel.swift
//  RumahIblis
//
//  Created by Figo Alessandro Lehman on 04/04/23.
//

import SwiftUI

class IblisViewModel: ObservableObject{
    @Published var iblisList: [Iblis] = [
        Iblis(name: "Pocong", image: "pocong", hint: "Pocong lives in cemeteries and banana groves, their body is covered with shroud and moves around by jumping.", answerChoices: [Answer(answer: "Pocong", isCorrect: true), Answer(answer: "Kuntilanak", isCorrect: false), Answer(answer: "Tuyul", isCorrect: false)]),
        Iblis(name: "Kuntilanak", image: "kuntilanak", hint: "Kuntilanak is a long-haired ghost wearing white clothes from shoulder to toe. This ghost resides in certain trees like hibiscus which grow leaning to the side. She is afraid of sharp objects like nails, knives and scissors.", answerChoices: [Answer(answer: "Pocong", isCorrect: false), Answer(answer: "Kuntilanak", isCorrect: true), Answer(answer: "Tuyul", isCorrect: false)]),
        Iblis(name: "Tuyul", image: "tuyul", hint: "This ghost with a body size like a child or a small baby, and with a bald head is often referred to as a bald devil. They are often likened to a pet that can be used by their keeper to steal something.", answerChoices: [Answer(answer: "Pocong", isCorrect: false), Answer(answer: "Kuntilanak", isCorrect: false), Answer(answer: "Tuyul", isCorrect: true)]),
        Iblis(name: "Genderuwo", image: "genderuwo", hint: "This ghost with a body like a giant ape that has muscular body comes from Javanese myths. This ghost is mischievous and obscene that often seduces women and children.", answerChoices: [Answer(answer: "Genderuwo", isCorrect: true), Answer(answer: "Kuntilanak", isCorrect: false), Answer(answer: "Tuyul", isCorrect: false)]),
        Iblis(name: "Buto Ijo", image: "butoijo", hint: "This giant green-bodied figure is a ghost that is told in the folklore of Central Java, Timun Mas. This ghost is also often used to grant human wishes in exchange for which is usually a human life.", answerChoices: [Answer(answer: "Buto Ijo", isCorrect: true), Answer(answer: "Kuntilanak", isCorrect: false), Answer(answer: "Tuyul", isCorrect: false)]),
        Iblis(name: "Hantu Jeruk Purut", image: "jerukpurut", hint: "This ghost got no head and dressed like a priest. They live in TPU Jeruk Purut, Jakarta. It is believed that he struggles to find his own grave in TPU Jeruk Purut.", answerChoices: [Answer(answer: "Hantu Jeruk Purut", isCorrect: true), Answer(answer: "Ahool", isCorrect: false), Answer(answer: "Jerangkong", isCorrect: false)]),
        Iblis(name: "Krasue", image: "krasue", hint: "Krasue is a female ghost with her internal organs hanging down from the trachea, trailing below the head. She moves by hovering in the air and it is believed by the Indonesian people that she haunts the blood of newborn babies and women after pregnancy", answerChoices: [Answer(answer: "Krasue", isCorrect: true), Answer(answer: "Jenglot", isCorrect: false), Answer(answer: "Jaka Tunggul", isCorrect: false)]),
        Iblis(name: "Sundel Bolong", image: "sundelbolong", hint: "Sundel bolong is a female ghost with a hole in her back. It is believed that she died when she was pregnant, and the baby came out unalive from her back.", answerChoices: [Answer(answer: "Sundel Bolong", isCorrect: true), Answer(answer: "Leak", isCorrect: false), Answer(answer: "Wewe Gombel", isCorrect: false)]),
        Iblis(name: "Jenglot", image: "jenglot", hint: "Jenglot is a small creature that has the appearance of a deformed humanoid doll. With black magic, this ghost takes revenge on an enemy and works as a good luck charm for their keeper. It is believed that their keeper feed them with blood.", answerChoices: [Answer(answer: "Jenglot", isCorrect: true), Answer(answer: "Jinn", isCorrect: false), Answer(answer: "Jelangkung", isCorrect: false)]),
        Iblis(name: "Jurig Gulutuk Sengir", image: "kepala", hint: "This ghost appears in the form of a head. It is believed that this ghost only show themselves to peddler by rolling in front of them and then stop to give a creepy smile, then roll away to the bushes.", answerChoices: [Answer(answer: "Jurig Gulutuk Sengir", isCorrect: true), Answer(answer: "Rolling Stone", isCorrect: false), Answer(answer: "Suster Ngesot", isCorrect: false)])
    ]
    
    func shuffleOrder(){
        for var iblis in iblisList{
            iblis.answerChoices.shuffle()
        }
        iblisList.shuffle()
    }
    
}
