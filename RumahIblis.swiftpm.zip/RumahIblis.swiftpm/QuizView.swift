//
//  QuizView.swift
//  RumahIblis
//
//  Created by Figo Alessandro Lehman on 04/04/23.
//

import SwiftUI

struct QuizView: View {
    @State var score = 0
    @State var isShown = ""
    @State var index = 0
    @State private var correctIndex = -1
    @ObservedObject var iblisVM: IblisViewModel = IblisViewModel()
    var body: some View {
        NavigationView {
            ZStack {
                VStack{
                    HStack{
                        
                        ProgressBar(index: $index)
                        
                        Spacer()
                    }
                    .padding()
                    .onChange(of: index, perform: { newValue in
                        self.correctIndex = iblisVM.iblisList[index].answerChoices.firstIndex(where: {
                            $0.isCorrect
                        })!
                    })
                    Image(iblisVM.iblisList[index].image).resizable()

                    AnswerChoice(answer: $iblisVM.iblisList[index].answerChoices[0], index: $index, isShown: $isShown, score: $score)
                    .onAppear{
                        self.correctIndex = iblisVM.iblisList[index].answerChoices.firstIndex(where: {
                            $0.isCorrect
                        })!
                    }
                    
                    AnswerChoice(answer: $iblisVM.iblisList[index].answerChoices[1], index: $index, isShown: $isShown, score: $score)
                    
                    AnswerChoice(answer: $iblisVM.iblisList[index].answerChoices[2], index: $index, isShown: $isShown, score: $score)
                    
                    Spacer()
                }
                .background(Color(.systemGreen))
                
                if isShown != ""{
                    Color.black.opacity(0.4)
                        .edgesIgnoringSafeArea(.all)
                    
                    VStack {
                        Spacer()
                        PopupView(result: isShown, info: $iblisVM.iblisList[index].hint, index: $index, correctAnswer: $iblisVM.iblisList[index].answerChoices[correctIndex].answer)
                        Spacer()
                    }
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding()
                    .frame(width: 100,height: 100)
                    VStack{
                        Spacer()
                        Button{
                            isShown = ""
                            index += 1
                        } label:{
                            Text("NEXT")
                        }
                    }
                   
                }
            }
        }
        
    }
}

struct QuizView_Previews: PreviewProvider {
    static var previews: some View {
        QuizView()
    }
}
