//
//  AnswerModel.swift
//  RumahIblis
//
//  Created by Figo Alessandro Lehman on 05/04/23.
//

import Foundation

struct Answer: Identifiable{
    var id = UUID()
    var answer: String
    var isCorrect: Bool
}
