//
//  Iblis.swift
//  RumahIblis
//
//  Created by Figo Alessandro Lehman on 04/04/23.
//

import Foundation

struct Iblis: Identifiable{
    var id = UUID()
    var name: String
    var image: String
    var hint: String
    var answerChoices: [Answer]
}
