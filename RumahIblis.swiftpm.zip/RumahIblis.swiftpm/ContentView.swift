//
//  ContentView.swift
//  RumahIblis
//
//  Created by Figo Alessandro Lehman on 04/04/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        NavigationView {
            VStack {
                HStack{
                    Text("Rumah")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                    Text("Iblis")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .foregroundColor(Color("AccentColor"))
                }.padding()
                NavigationLink(destination: QuizView()){
                    Image(systemName: "play.fill")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundColor(Color("AccentColor"))
                }.padding()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .edgesIgnoringSafeArea(.all)
        .background(Color(.systemGreen))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
