//
//  AnswerChoice.swift
//  RumahIblis
//
//  Created by Figo Alessandro Lehman on 05/04/23.
//

import SwiftUI

struct AnswerChoice: View {
    @Binding var answer: Answer
    @Binding var index: Int
    @Binding var isShown: String
    @Binding var score: Int
    var body: some View {
        Button{
            if answer.isCorrect {
                isShown = "Correct"
            }
            else {
                isShown = "Wrong"
            }
        } label:{
            Text(answer.answer)
                .foregroundColor(Color.white)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(width: 300, height: 70)
        .buttonStyle(.borderedProminent)
        .foregroundColor(Color("AccentColor"))
    }
}

struct AnswerChoice_Previews: PreviewProvider {
    static var previews: some View {
        AnswerChoice(answer: .constant(Answer(answer: "bener ga ya", isCorrect: true)), index: .constant(1), isShown: .constant(""), score: .constant(0))
    }
}
