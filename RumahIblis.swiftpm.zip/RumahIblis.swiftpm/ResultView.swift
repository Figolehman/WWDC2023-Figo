//
//  ResultView.swift
//  RumahIblis
//
//  Created by Figo Alessandro Lehman on 08/04/23.
//

import SwiftUI

struct ResultView: View {
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ResultView_Previews: PreviewProvider {
    static var previews: some View {
        ResultView()
    }
}
